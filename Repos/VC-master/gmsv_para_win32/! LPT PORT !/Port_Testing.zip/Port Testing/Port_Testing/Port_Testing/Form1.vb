'Port Testing
'Created by: phebejtsov@yahoo.com
'Date: Aug 09, 2006
'This simple program shows new/experience programers
'how to communicate via parallel port.  
'When Button1 is clicked Data is written
'and read from on the 'data port' to confirm that data
'port works. When Button2 is clicked External data can
'be read through the �signal port�.


Option Strict Off
Option Explicit On
Module InpOut32_Declarations

    'Inp and Out declarations for port I/O using inpout32.dll.
    Public Declare Function Inp Lib "inpout32.dll" Alias "Inp32" (ByVal PortAddress As Short) As Short
    Public Declare Sub Out Lib "inpout32.dll" Alias "Out32" (ByVal PortAddress As Short, ByVal Value As Short)

End Module


Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Out(&H378S, &HFFS)      'Print '1' to D7-D0 or 255 in Decimal
        Dim Value1 As String    'String named Value1
        Value1 = Inp(&H378S)    'Now Value1 has the values in 'data port'
        MessageBox.Show(Value1) 'A popup will indicate the current value written

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        Dim Value2 As String    'String named Value2
        Value2 = Inp(&H379S)    'Now Value2 has the values in 'signal port'
        MessageBox.Show(Value2) 'A popup will indicate the current value written

    End Sub
End Class
